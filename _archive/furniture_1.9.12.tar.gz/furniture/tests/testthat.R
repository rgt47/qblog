library(testthat)
library(furniture)

test_check("furniture")
