library(testthat)
library(atable)

test_check("atable")
